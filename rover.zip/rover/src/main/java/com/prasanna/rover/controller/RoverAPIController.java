package com.prasanna.rover.controller;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.prasanna.rover.models.InputModel;
import com.prasanna.rover.models.PositionModel;

@RestController
public class RoverAPIController {
	
	@PostMapping
	public PositionModel GetCurrentPosition(@RequestBody InputModel input) {
		return null;
	};
	
	
	@PostMapping
	public PositionModel GetCurrentPositionFromFile(@RequestBody InputModel input) {
		return null;
	};

}
