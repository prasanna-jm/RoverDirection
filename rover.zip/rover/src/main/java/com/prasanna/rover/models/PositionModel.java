package com.prasanna.rover.models;

public class PositionModel {
 private String Direction;
 
 private String X;
 
 private String Y;

public String getDirection() {
	return Direction;
}

public void setDirection(String direction) {
	Direction = direction;
}

public String getX() {
	return X;
}

public void setX(String x) {
	X = x;
}

public String getY() {
	return Y;
}

public void setY(String y) {
	Y = y;
}
 
 
}
