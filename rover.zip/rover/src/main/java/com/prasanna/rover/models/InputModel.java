package com.prasanna.rover.models;

public class InputModel {

	private PositionModel position;
	
	private MoveModel move;

	public PositionModel getPosition() {
		return position;
	}

	public void setPosition(PositionModel position) {
		this.position = position;
	}

	public MoveModel getMove() {
		return move;
	}

	public void setMove(MoveModel move) {
		this.move = move;
	}
	
	
}
