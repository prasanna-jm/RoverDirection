package com.prasanna.rover.helperclasses;

import org.springframework.stereotype.Component;

@Component
public class PointHelper {

    private int location;
    public void setLocation(int value) { location = value; }
    public int getLocation() { return location; }

    private int maxLocation;
    public void setMaxLocation(int value) { maxLocation = value; }
    public int getMaxLocation() { return maxLocation; }

    public PointHelper(int locationValue, int maxLocationValue) {
        setLocation(locationValue);
        setMaxLocation(maxLocationValue);
    }

    public int getForwardLocation() {
        return (getLocation() + 1) % (getMaxLocation() + 1);
    }

    public int getBackwardLocation() {
        if (getLocation() > 0) return getLocation() - 1;
        else return getMaxLocation();
    }

}