package com.prasanna.rover.helperclasses;

import java.util.List;

import org.springframework.stereotype.Component;

@Component
public class CoordinatesHelper {

    private PointHelper x;
    public void setX(PointHelper value) { x = value; }
    public PointHelper getX() { return x; }

    private PointHelper y;
    public void setY(PointHelper value) { y = value; }
    public PointHelper getY() { return y; }

    private DirectionHelper direction;
    public void setDirection(DirectionHelper value) {
        direction = value;
    }
    public DirectionHelper getDirection() {
        return direction;
    }

    private List<Obstacle> obstacles;
    public void setObstacles(List<Obstacle> value) {
        obstacles = value;
    }
    public List<Obstacle> getObstacles() {
        return obstacles;
    }

    private boolean foundObstacle = false;

    public CoordinatesHelper(PointHelper xValue,
                       PointHelper yValue,
                       DirectionHelper directionValue,
                       List<Obstacle> obstaclesValue) {
        setX(xValue);
        setY(yValue);
        setDirection(directionValue);
        setObstacles(obstaclesValue);
    }

    protected boolean move(DirectionHelper directionValue) {
        int xLocation = x.getLocation();
        int yLocation = y.getLocation();
        switch (directionValue) {
            case NORTH:
                yLocation = y.getForwardLocation();
                break;
            case EAST:
                xLocation = x.getForwardLocation();
                break;
            case SOUTH:
                yLocation = y.getBackwardLocation();
                break;
            case WEST:
                xLocation = x.getBackwardLocation();
                break;
        }
        if (!hasObstacle(xLocation, yLocation)) {
            x.setLocation(xLocation);
            y.setLocation(yLocation);
            return true;
        } else {
            return false;
        }
    }

    private boolean hasObstacle(int xLocation, int yLocation) {
        for (Obstacle obstacle : obstacles) {
            if (obstacle.getX() == xLocation && obstacle.getY() == yLocation) {
                foundObstacle = true;
                return true;
            }
        }
        return false;
    }

    public boolean moveForward() {
        return move(direction);
    }

    public boolean moveBackward() {
        return move(direction.getBackwardDirection());
    }

    private void changeDirection(DirectionHelper directionValue, int directionStep) {
        int directions = DirectionHelper.values().length;
        int index = (directions + directionValue.getValue() + directionStep) % directions;
        direction = DirectionHelper.values()[index];
    }

    public void changeDirectionLeft() {
        changeDirection(direction, -1);
    }

    public void changeDirectionRight() {
        changeDirection(direction, 1);
    }

    @Override
    public String toString() {
        String status = "";
        if (foundObstacle) {
            status = " NOK";
        }
        return getX().getLocation() + " X " + getY().getLocation() + " " + getDirection().getShortName() + status;
    }

}
