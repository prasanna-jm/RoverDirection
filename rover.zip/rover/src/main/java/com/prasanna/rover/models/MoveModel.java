package com.prasanna.rover.models;

public class MoveModel {
	private String Order;
	
	private String Cmd1;
	
	private Integer cmdVal1;
	
	private String Cmd2;
	
	private Integer cmdVal2;

	public String getOrder() {
		return Order;
	}

	public void setOrder(String order) {
		Order = order;
	}

	public String getCmd1() {
		return Cmd1;
	}

	public void setCmd1(String cmd1) {
		Cmd1 = cmd1;
	}

	public Integer getCmdVal1() {
		return cmdVal1;
	}

	public void setCmdVal1(Integer cmdVal1) {
		this.cmdVal1 = cmdVal1;
	}

	public String getCmd2() {
		return Cmd2;
	}

	public void setCmd2(String cmd2) {
		Cmd2 = cmd2;
	}

	public Integer getCmdVal2() {
		return cmdVal2;
	}

	public void setCmdVal2(Integer cmdVal2) {
		this.cmdVal2 = cmdVal2;
	} 
	
}
